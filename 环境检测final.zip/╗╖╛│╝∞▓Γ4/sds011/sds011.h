#include "stm32f10x.h"
#include "misc.h"

void GPIO_Configuration_sds011(void);	
void RCC_Configuration_sds011(void);
void USART_Configuration_sds011(void);
void NVIC_Configuration_sds011(void);
void sds011_USART_Init(void);
