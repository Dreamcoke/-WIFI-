#include "stm32f10x.h"
#include "misc.h"

void GPIO_Configuration_arofene(void);	
void RCC_Configuration_arofene(void);
void USART_Configuration_arofene(void);
void NVIC_Configuration_arofene(void);
void arofene_USART_Init(void);
